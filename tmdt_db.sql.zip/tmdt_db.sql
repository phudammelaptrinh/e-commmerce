-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 15, 2024 at 06:06 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tmdt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `congty`
--

CREATE TABLE `congty` (
  `idcty` int(11) NOT NULL auto_increment,
  `tencty` varchar(255) default NULL,
  `diachi` varchar(255) default NULL,
  `dienthoai` varchar(20) default NULL,
  `fax` varchar(20) default NULL,
  PRIMARY KEY  (`idcty`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `congty`
--

INSERT INTO `congty` (`idcty`, `tencty`, `diachi`, `dienthoai`, `fax`) VALUES
(1, 'Apple', 'USA', NULL, NULL),
(2, 'Samsung', 'South Korea ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dathang`
--

CREATE TABLE `dathang` (
  `iddh` int(10) unsigned NOT NULL auto_increment,
  `idkh` int(11) NOT NULL,
  `id_nhanvien` int(11) NOT NULL,
  `ngaydathang` datetime NOT NULL,
  `trangthai` int(11) NOT NULL,
  PRIMARY KEY  (`iddh`),
  UNIQUE KEY `iddh` (`iddh`),
  UNIQUE KEY `iddh_2` (`iddh`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=111 ;

--
-- Dumping data for table `dathang`
--

INSERT INTO `dathang` (`iddh`, `idkh`, `id_nhanvien`, `ngaydathang`, `trangthai`) VALUES
(82, 1, 0, '2024-04-26 00:00:00', 0),
(83, 1, 0, '2024-04-26 00:00:00', 0),
(84, 1, 0, '2024-04-27 00:00:00', 0),
(85, 1, 0, '2024-04-27 00:00:00', 0),
(86, 1, 0, '2024-04-27 00:00:00', 0),
(87, 1, 0, '2024-04-27 00:00:00', 0),
(88, 1, 0, '2024-04-27 00:00:00', 0),
(89, 1, 0, '2024-04-27 00:00:00', 0),
(90, 1, 0, '2024-04-28 00:00:00', 0),
(91, 1, 0, '2024-04-28 00:00:00', 0),
(92, 1, 0, '2024-04-28 00:00:00', 0),
(93, 1, 0, '2024-04-28 00:00:00', 0),
(94, 1, 0, '2024-04-28 00:00:00', 0),
(95, 1, 0, '2024-04-28 00:00:00', 0),
(96, 1, 0, '2024-04-28 00:00:00', 0),
(97, 1, 0, '2024-04-28 00:00:00', 0),
(98, 1, 0, '2024-04-28 00:00:00', 0),
(99, 1, 0, '2024-04-28 00:00:00', 0),
(100, 1, 0, '2024-04-28 00:00:00', 0),
(101, 1, 0, '2024-04-28 00:00:00', 0),
(102, 1, 0, '2024-04-28 00:00:00', 0),
(103, 1, 0, '2024-04-28 00:00:00', 0),
(104, 1, 0, '2024-04-28 00:00:00', 0),
(105, 1, 0, '2024-04-28 00:00:00', 0),
(106, 1, 0, '2024-04-28 00:00:00', 0),
(107, 1, 0, '2024-04-29 00:00:00', 0),
(108, 1, 0, '2024-04-29 00:00:00', 0),
(109, 1, 0, '2024-04-29 00:00:00', 0),
(110, 1, 0, '2024-04-29 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dathang_chitiet`
--

CREATE TABLE `dathang_chitiet` (
  `iddh` int(10) unsigned NOT NULL,
  `idsp` int(11) NOT NULL,
  `soluong` int(11) NOT NULL,
  `dongia` float NOT NULL,
  `giamgia` float NOT NULL,
  UNIQUE KEY `khongtrung` (`iddh`,`idsp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dathang_chitiet`
--

INSERT INTO `dathang_chitiet` (`iddh`, `idsp`, `soluong`, `dongia`, `giamgia`) VALUES
(102, 4, 1, 100, 2),
(103, 4, 1, 100, 2),
(106, 4, 1, 100, 2),
(107, 4, 1, 100, 2),
(108, 4, 1, 100, 2),
(109, 4, 1, 100, 2),
(110, 4, 1, 100, 2);

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `iduser` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `phanquyen` int(11) NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ten` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `diachi` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `diachinhanhang` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `dienthoai` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`iduser`),
  UNIQUE KEY `username` (`username`),
  KEY `password` (`password`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`iduser`, `username`, `password`, `phanquyen`, `hodem`, `ten`, `diachi`, `diachinhanhang`, `dienthoai`) VALUES
(1, 'khachhang@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1, 'Ho ', 'A', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `idsp` int(11) NOT NULL auto_increment,
  `tensp` varchar(255) default NULL,
  `gia` decimal(10,2) default NULL,
  `mota` text,
  `hinh` varchar(255) default NULL,
  `giamgia` decimal(5,2) default NULL,
  `idcty` int(11) default NULL,
  PRIMARY KEY  (`idsp`),
  KEY `idcty` (`idcty`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`idsp`, `tensp`, `gia`, `mota`, `hinh`, `giamgia`, `idcty`) VALUES
(4, 'iPhone 11', '100.00', 'San pham moi 100%', '1712833439_1712734850_iphone 11.jpg', '2.00', 1),
(5, 'Samsung S7', '100.00', 'san pham moi 100%', '1712833458_1712734731_samsung-s8.jpg', '5.00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `iduser` int(11) NOT NULL auto_increment,
  `username` varchar(50) default NULL,
  `password` varchar(255) default NULL,
  `hodem` varchar(50) default NULL,
  `ten` varchar(50) default NULL,
  `phanquyen` varchar(20) default NULL,
  `landangnhapcuoi` datetime default NULL,
  PRIMARY KEY  (`iduser`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`iduser`, `username`, `password`, `hodem`, `ten`, `phanquyen`, `landangnhapcuoi`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'test', 'admin', '1', '2024-04-11 16:05:18');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `sanpham_ibfk_1` FOREIGN KEY (`idcty`) REFERENCES `congty` (`idcty`);
